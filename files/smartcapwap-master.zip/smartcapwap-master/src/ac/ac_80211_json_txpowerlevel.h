#ifndef __AC_JSON_80211_TXPOWERLEVEL_HEADER__
#define __AC_JSON_80211_TXPOWERLEVEL_HEADER__

#include "capwap_element_80211_txpowerlevel.h"

extern struct ac_json_ieee80211_ops ac_json_80211_txpowerlevel_ops;

#endif /* __AC_JSON_80211_TXPOWERLEVEL_HEADER__ */
