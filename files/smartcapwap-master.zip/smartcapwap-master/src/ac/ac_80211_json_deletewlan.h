#ifndef __AC_JSON_80211_DELETEWLAN_HEADER__
#define __AC_JSON_80211_DELETEWLAN_HEADER__

#include "capwap_element_80211_deletewlan.h"

extern struct ac_json_ieee80211_ops ac_json_80211_deletewlan_ops;

#endif /* __AC_JSON_80211_DELETEWLAN_HEADER__ */
