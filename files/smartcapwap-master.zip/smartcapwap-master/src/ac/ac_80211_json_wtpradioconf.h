#ifndef __AC_JSON_80211_WTPRADIOCONF_HEADER__
#define __AC_JSON_80211_WTPRADIOCONF_HEADER__

#include "capwap_element_80211_wtpradioconf.h"

extern struct ac_json_ieee80211_ops ac_json_80211_wtpradioconf_ops;

#endif /* __AC_JSON_80211_WTPRADIOCONF_HEADER__ */
