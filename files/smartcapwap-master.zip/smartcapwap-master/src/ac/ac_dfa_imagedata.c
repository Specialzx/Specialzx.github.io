#include "ac.h"
#include "capwap_dfa.h"
#include "capwap_array.h"
#include "ac_session.h"

/* */
void ac_dfa_state_imagedata(struct ac_session_t* session, struct capwap_parsed_packet* packet) {
	/* TODO */
	ac_session_teardown(session);
}
