#ifndef __AC_JSON_80211_MICCOUNTERMEASURES_HEADER__
#define __AC_JSON_80211_MICCOUNTERMEASURES_HEADER__

#include "capwap_element_80211_miccountermeasures.h"

extern struct ac_json_ieee80211_ops ac_json_80211_miccountermeasures_ops;

#endif /* __AC_JSON_80211_MICCOUNTERMEASURES_HEADER__ */
